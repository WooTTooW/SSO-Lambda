#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import time
import logging
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import openpyxl

# =====================
# CONFIG FROM ENVIRONMENT
# =====================
INSTANCE_ARN = os.environ['INSTANCE_ARN']
IDENTITY_STORE_ID = os.environ['IDENTITY_STORE_ID']
REGION = os.environ.get('REGION', 'ap-southeast-1')
S3_BUCKET_TEMPLATE = os.environ['S3_BUCKET_TEMPLATE']  # Bucket ที่เก็บ template และ output

TEMPLATE_KEY = 'sso-assignments-template.xlsx'
TIMESTAMP = time.strftime("%Y%m%d")
OUTPUT_KEY = f"sso-assignments-{TIMESTAMP}.xlsx"
LOCAL_TEMPLATE = f"/tmp/{TEMPLATE_KEY}"
LOCAL_OUTPUT = f"/tmp/{OUTPUT_KEY}"

# =====================
# LOGGING
# =====================
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("lambda-sso")

# =====================
# AWS CLIENTS
# =====================
cfg = Config(retries={"max_attempts": 10, "mode": "standard"})
session = boto3.Session(region_name=REGION)
org = session.client("organizations", config=cfg)
sso = session.client("sso-admin", config=cfg)
ids = session.client("identitystore", config=cfg)
s3 = session.client("s3", config=cfg)

# =====================
# CACHES
# =====================
user_cache = {}
ou_cache = {}

# =====================
# Helper Functions
# =====================
def get_user_name(user_id):
    if user_id in user_cache:
        return user_cache[user_id], ""
    try:
        u = ids.describe_user(IdentityStoreId=IDENTITY_STORE_ID, UserId=user_id)
        name = u.get("UserName") or u.get("DisplayName") or "UNKNOWN_NAME"
        user_cache[user_id] = name
        return name, ""
    except ClientError as e:
        code = e.response['Error']['Code']
        if code in ("ResourceNotFoundException","ValidationException"):
            return "NOT_FOUND_IN_IDENTITY_STORE", code
        return "ERROR", code

def get_bu_name(account_id):
    try:
        parents = org.list_parents(ChildId=account_id)["Parents"]
        parent = parents[0]
        if parent["Type"] == "ROOT":
            return "ROOT"
        ou_id = parent["Id"]
        if ou_id in ou_cache:
            return ou_cache[ou_id]
        ou_info = org.describe_organizational_unit(OrganizationalUnitId=ou_id)
        ou_name = ou_info["OrganizationalUnit"]["Name"]
        ou_cache[ou_id] = ou_name
        return ou_name
    except ClientError as e:
        log.warning(f"Cannot get BU for {account_id}: {e.response['Error']['Code']}")
        return "ERROR_GET_BU"

# =====================
# Generate SSO Report
# =====================
def generate_sso_report():
    # ดาวน์โหลด template จาก S3
    s3.download_file(S3_BUCKET_TEMPLATE, TEMPLATE_KEY, LOCAL_TEMPLATE)
    log.info(f"Template downloaded: {LOCAL_TEMPLATE}")

    wb = openpyxl.load_workbook(LOCAL_TEMPLATE)
    ws = wb.active

    # ดึงรายชื่อ accounts
    accounts=[]
    for page in org.get_paginator("list_accounts").paginate():
        accounts.extend(page.get("Accounts",[]))
    log.info(f"Total accounts: {len(accounts)}")

    # loop แต่ละ account
    for i, acct in enumerate(accounts,1):
        acct_id = acct["Id"]
        acct_name = acct["Name"]
        bu_name = get_bu_name(acct_id)

        # ดึง permission sets
        ps_arns=[]
        for p in sso.get_paginator("list_permission_sets_provisioned_to_account").paginate(
            InstanceArn=INSTANCE_ARN, AccountId=acct_id
        ):
            ps_arns.extend(p.get("PermissionSets",[]))

        for perm_arn in ps_arns:
            try:
                perm_name = sso.describe_permission_set(
                    InstanceArn=INSTANCE_ARN, PermissionSetArn=perm_arn
                )["PermissionSet"]["Name"]
            except ClientError:
                perm_name = "ERROR_GETTING_NAME"

            assigns=[]
            for ap in sso.get_paginator("list_account_assignments").paginate(
                InstanceArn=INSTANCE_ARN, AccountId=acct_id, PermissionSetArn=perm_arn
            ):
                assigns.extend(ap.get("AccountAssignments",[]))

            for a in assigns:
                if a.get("PrincipalType")=='USER':
                    uid=a["PrincipalId"]
                    uname,note=get_user_name(uid)
                    ws.append([acct_id, bu_name, acct_name, uid, uname, perm_name, note])

    # save locally
    wb.save(LOCAL_OUTPUT)
    log.info(f"Report saved locally: {LOCAL_OUTPUT}")

    # upload ไป S3
    try:
        s3.upload_file(LOCAL_OUTPUT, S3_BUCKET_TEMPLATE, OUTPUT_KEY)
        log.info(f"Report uploaded to S3: s3://{S3_BUCKET_TEMPLATE}/{OUTPUT_KEY}")
    except ClientError as e:
        log.error(f"Failed to upload Excel to S3: {e.response['Error']['Code']}")

    return LOCAL_OUTPUT

# =====================
# Lambda Handler
# =====================
def lambda_handler(event, context):
    log.info("Lambda triggered")
    report_file = generate_sso_report()
    return {
        'statusCode': 200,
        'body': f"Report generated and uploaded to s3://{S3_BUCKET_TEMPLATE}/{OUTPUT_KEY}"
    }
